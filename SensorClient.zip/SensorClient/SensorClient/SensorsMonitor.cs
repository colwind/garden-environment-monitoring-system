﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
//引入
using System.Threading;
using System.Net.NetworkInformation;
using System.Net;

namespace SensorClient
{
    /*
     * 智慧农业监控客户端类
     */
    public partial class SensorsMonitor : Form
    {
        public SensorsMonitor()
        {
            InitializeComponent();
        }
        //定义变量
        #region 定义变量
        //网关序列号：三段点分的一个整数
        private int bClass = 0;//设备类型
        private int uBlock = 0;//终端设备硬件的批号
        private int uAddr = 0;//终端设备地址

        //定义两个线程

        private Thread receiveThd = null;//采集网管主动上报的数据线程
        private Thread receiveThdByManual = null;//采集网关查询应答的数据的线程

        //定义一个定时器
        //检查网关是否在线的定时器
        private System.Threading.Timer isOnlineGateWayTm;


        //定义以下通信数据格式的标志
        private static bool flagBit7 = false;//是否是无符号数，true：有符号数；false：无符号数
        private static bool flagBit6 = false;//量的类型，true：开关量；false：数值
        private static bool flagBit5 = false;//长整数数值标识，true：四字节；false：双字节
        private static bool flagBit4 = false;//四字节标识，true：高位；false：低位

        #endregion
        //加载动态链接库函数   
        #region 动态链接库函数
        [DllImport("Netfree.dll")]
        public static extern short StartServiceTCP(int uPort);//启动TCP服务:服务启动正常返回 1
        [DllImport("Netfree.dll")]
        public static extern void StopService();//停止服务     
        [DllImport("Netfree.dll")]
        public static extern void EnableAutoRequest(bool bMode); //允许自动查询寄存器
        [DllImport("Netfree.dll")]
        public static extern int IsOnline(int bClass, int uBlock, int uAddr);//检查设备是否在线:设备在线返回 TRUE，不在线返回 FALSE
        #region 配置指令
        [DllImport("Netfree.dll")]
        public static extern void SetAutoRequestPeriod(int uSecond); //设置自动查询寄存器周期：默认2分钟：120s
        [DllImport("Netfree.dll")]
        public static extern void SetInterval(int uMilliSecond);//设置动态库处理队列指令周期，默认1000ms :1秒
        [DllImport("Netfree.dll")]
        public static extern void SetResend(int uTime);//设置下发指令无反应，动态库的重发次数，默认5次 
        #endregion
        #region 下发指令
        [DllImport("Netfree.dll")]
        public static extern bool ReadHoldingRegisters(int bClass, int uBlock, int uAddr, int uStartAddr, int uRegNum);  //下发：向设备下发读保持寄存器操作命令:正确执行并下发返回 TRUE，产生错误返回 FALSE，通过调用 GetReturn 或 GetReturnHex 函数获取未解析的设备应答    
        [DllImport("Netfree.dll")]
        public static extern bool ReadInputRegisters(int bClass, int uBlock, int uAddr, int uStartAddr, int uRegNum);//下发：向设备下发读模拟量通道数据命令,  //通过调用 GetReturn 或 GetReturnHex 函数获取未解析的设备应答  
        [DllImport("Netfree.dll")]
        public static extern bool ReadChannels(int bClass, int uBlock, int uAddr); //下发：向设备下发读全通道值指令，命令成功下发后， 当判断到终端返回数据时， 可通过提供的 GetChnlDigital、 GetChnlCoil、GetChnlDataI 等函数获得各通道值数字量及模拟量值   
        [DllImport("Netfree.dll")]
        public static extern bool ReadCoils(int bClass, int uBlock, int uAddr, int uStartAddr, int uRegNum);//下发：读继电器数据命令 ,通过调用 GetCoil 函数获取结果
        [DllImport("Netfree.dll")]
        public static extern bool ReadDigitals(int bClass, int uBlock, int uAddr, int uStartAddr, int uRegNum);//下发：读数字量通道数据命令,通过调用 GetDigital 函数获取解析结果 
        #endregion
        [DllImport("Netfree.dll")]
        public static extern bool HasError(int bClass, int uBlock, int uAddr, int uSubAddr);//调用相关函数获得返回数据前，通过该方法判断是否有错误产生
        [DllImport("Netfree.dll")]
        public static extern String GetError(int bClass, int uBlock, int uAddr, int uSubAddr);//当判断 HasError 函数返回 TURE 后，通过调用该函数得到错误说明
        //下发命令后，调用该方法获得其运行状态,命令处理完毕返回 TRUE， 包括有效数据返回和执行时产生错误情况； 命令未执行完返回FALSE
        [DllImport("Netfree.dll")]
        public static extern bool HasReturn(int bClass, int uBlock, int uAddr, int uSubAddr);
        #region 获取指令
        [DllImport("Netfree.dll")]
        public static extern int GetData(int bClass, int uBlock, int uAddr, int iRegNum, ref int[] iData);//获得模拟量通道数据解析的整形值, 传入的整形数组指针，用于传出通道模拟量数据
        [DllImport("Netfree.dll")]
        public static extern int GetCoil(int bClass, int uBlock, int uAddr, int iRegNum, ref bool[] bData);//获取指定终端继电器通道的解析值， 即解析 Modbus 中 01 功能码的命令返回
        [DllImport("Netfree.dll")]
        public static extern int GetDigital(int bClass, int uBlock, int uAddr, int iRegNum, ref bool[] bData);//获取指定终端数字量通道解析值，即解析 Modbus 中 02 功能码的命令返回
        [DllImport("Netfree.dll")]
        public static extern String GetReturn(int bClass, int uBlock, int uAddr, int uSubAddr);//获得指定终端设备执行用户下发命令后的返回结果（用户发送请求命令的运行结果， ASCII 码形式字符串）
        [DllImport("Netfree.dll")]
        public static extern String GetReturnHex(int bClass, int uBlock, int uAddr, int uSubAddr);//获取用户下发指令后的返回结果 
        [DllImport("Netfree.dll")]
        public static extern String GetChannels(int bClass, int uBlock, int uAddr);//获取全通道未解析的原始数据串
        [DllImport("Netfree.dll")]
        public static extern int GetChnlDigital(int bClass, int uBlock, int uAddr, int iChnlNum, ref bool[] bData);//获取指定终端全通道数据中解析获得的数字量值
        [DllImport("Netfree.dll")]
        public static extern int GetChnlCoil(int bClass, int uBlock, int uAddr, int iChnlNum, ref bool[] bData);//获取指定终端全通道数据中解析获得的继电器值
        [DllImport("Netfree.dll")]
        public static extern int GetChnlDataW(int bClass, int uBlock, int uAddr, int iChnlNum, ref long[] wData);//获得指定终端全通道数据中解析获得的完整通道模拟量数值
        #endregion
        #region 获取自动上报取数据
        [DllImport("Netfree.dll")]
        public static extern String GetAutoUpdateData(int bClass, int uBlock, int uAddr, int uSubAddr);//获取主动上报数据
        [DllImport("Netfree.dll")]
        public static extern String GetAutoUpdateDataHex(int bClass, int uBlock, int uAddr, int uSubAddr);//获取主动上报数据 
        #endregion
        #endregion

        //服务器连接配置
        private void tlsServerConfig_Click(object sender, EventArgs e)
        {
            SocketConfig sc = new SocketConfig();
            sc.ShowDialog();
        }
        //配置网关
        private void tlsGateWayConfig_Click(object sender, EventArgs e)
        {
            GateWayConfig gc = new GateWayConfig();
            gc.ShowDialog();
        }
        //检查网关配置
        private bool CheckGateWayConfig()
        {
            if (MySocket.gateWayIP == null ||
                MySocket.gateWayPort == 0 ||
                MySocket.gateWaySerialNumber == string.Empty ||
                MySocket.gateWayUploadDataType == string.Empty)
            {
                MessageBox.Show("请配置网关参数！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        //启动服务
        private void btnStartService_Click(object sender, EventArgs e)
        {
            if (!CheckGateWayConfig())
            {
                return;
            }
            else
            {
                //取出网关的相关参数
                char[] sp = new char[] { '.' };
                string[] gateWaySN = MySocket.gateWaySerialNumber.Split(sp);
                bClass = int.Parse(gateWaySN[0]);
                uBlock = int.Parse(gateWaySN[1]);
                uAddr = int.Parse(gateWaySN[2]);

                try
                {
                    if (StartServiceTCP(MySocket.gateWayPort) > 0)
                    {
                        MessageBox.Show("启动服务成功！", "提示",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //启动服务成功后界面控件的状态
                        BtnStatusByStartService();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("启动服务失败！原因：" + ex.Message, "提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }
        //启动服务成功后界面控件的状态
        private void BtnStatusByStartService()
        {
            //禁用启动服务的按钮
            btnStartService.Enabled = false;
            //启用停止服务的按钮
            btnStopService.Enabled = true;
            //启用检查网关是否在线的按钮
            btnIsOnline.Enabled = true;
            //启用监听网关的复选框
            chkGateWayListener.Enabled = true;
        }
        //停止服务成功后界面控件的状态
        private void BtnStatusByStopService()
        {
            //启用启动服务的按钮
            btnStartService.Enabled = true;
            //禁用停止服务的按钮
            btnStopService.Enabled = false;
            //禁用检查网关是否在线的按钮
            btnIsOnline.Enabled = false;
            //禁用监听网关的复选框
            chkGateWayListener.Enabled = false;
            chkGateWayListener.Checked = false;
            //禁用主动上报复选框,并取消选中状态
            chkAutoRequest.Checked = false;
            chkAutoRequest.Enabled = false;
            //禁用查询应答复选框，并取消选中状态
            chkRequest.Checked = false;
            chkRequest.Enabled = false;
        }
        //异步更新网关状态控件的图片
        private void UpdatepbGateWay(int status)
        {
            //取得应用程序执行启动的路径
            string appStr = System.Windows.Forms.Application.StartupPath;
            switch (status)
            {
                case 1:
                    pbGateWay.Image = Image.FromFile(appStr + @"\ico\success.gif");
                    break;
                case 0:
                    pbGateWay.Image = Image.FromFile(appStr + @"\ico\fail.gif");
                    break;
                default:
                    pbGateWay.Image = Image.FromFile(appStr + @"\ico\unknow.gif");
                    break;
            }
        }
        //是否在线按钮状态
        private void BtnChkIsOnline(int isOnline)
        {
            if (1 == isOnline)
            {
                //启用主动上报复选框
                chkAutoRequest.Enabled = true;
                //启用查询应答复选框
                chkRequest.Enabled = true;
            }
            else
            {
                //禁用主动上报复选框
                chkAutoRequest.Enabled = false;
                chkAutoRequest.Checked = false;
                //禁用查询应答复选框
                chkRequest.Enabled = false;
                chkRequest.Checked = false;
            }

        }
        //检查服务器连接配置
        private void CheckServerConfig()
        {
            //检查目标服务器IP、端口是否配置
            if (MySocket.remoteHostIP == string.Empty ||
                MySocket.remotePort == 0)
            {
                MessageBox.Show("服务器连接未配置！", "消息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                Ping ping = new Ping();
                PingReply reply = null;
                try
                {
                    reply = ping.Send(IPAddress.Parse(MySocket.remoteHostIP), 3000);//3s
                    if (reply != null && reply.Status == IPStatus.Success)
                    {
                        //检查客户端套接字是否连接
                        if (MySocket.client != null &&
                            MySocket.client.Connected)
                        {
                            MessageBox.Show("建立连接成功！服务器：" + MySocket.client.RemoteEndPoint.ToString() +
                                "\r\n客户端", "消息", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("服务器：" + MySocket.client.RemoteEndPoint.ToString() + "连接断开！",
                                "消息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("远程服务器无响应！", "消息", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("服务器无响应！", "消息", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }

            }
        }
        //检查网关是否在线
        private bool CheckIsOnline()
        {
            bool flag = false;
            Ping ping = new Ping();
            PingReply reply = null;

            try
            {
                reply = ping.Send(IPAddress.Parse(MySocket.gateWayIP), 1000);//1s

            }
            catch (Exception)
            {
            }
            int status = 0;
            if (reply != null && reply.Status == IPStatus.Success)
            {
                //调用dll中的函数检查网关是否在线，返回值：0不在线；1在线
                status = IsOnline(bClass, uBlock, uAddr);
            }
            //是否在线按钮状态
            BtnChkIsOnline(status);
            //异步更新网关状态控件的图片
            if (this.pbGateWay.InvokeRequired)
            {
                this.pbGateWay.Invoke(new MethodInvoker(delegate() { UpdatepbGateWay(status); }));

            }
            else
            {
                UpdatepbGateWay(status);
            }
            return flag = (status == 1) ? true : false;
        }
        // 停止服务
        private void btnStopService_Click(object sender, EventArgs e)
        {
            try
            {
                //终止接受数据的线程
                AbortReceiveThd();
                AbortReceiveThdByManul();
                //停止服务
                StopService();
                //停止服务成功后界面控件的状态
                BtnStatusByStopService();

                //异步更新网关状态控件的图片
                if (this.pbGateWay.InvokeRequired)
                {
                    this.pbGateWay.Invoke(new MethodInvoker(delegate() { UpdatepbGateWay(0); }));
                }
                else
                {
                    UpdatepbGateWay(0);
                }
                //停止监听网关的定时器
                if (isOnlineGateWayTm != null)
                {
                    isOnlineGateWayTm.Dispose();
                }
                MessageBox.Show("停止服务成功！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("停止服务失败！原因：" + ex.Message, "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //检查服务器
        private void bteCheckServer_Click(object sender, EventArgs e)
        {
            //检查服务器连接配置
            CheckServerConfig();
        }
        //检查网关
        private void btnIsOnline_Click(object sender, EventArgs e)
        {
            if (CheckIsOnline())
            {
                MessageBox.Show("网关设备在线", "提示", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("网关设备离线！（请检查网关是否连接或设备状态）", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //接受数据的线程要执行的函数
        private void ReceiveMsg()
        {
            string sourceStrHex = string.Empty;
            string receiveStrHex = string.Empty;

            while (true)
            {
                if (MySocket.gateWayUploadDataType == "主动上报")
                {
                    //调用网关的主动上报函数
                    receiveStrHex = GetAutoUpdateDataHex(bClass, uBlock, uAddr, 1);
                }
                else if (MySocket.gateWayUploadDataType == "查询应答")
                {
                    receiveStrHex = GetReturnHex(bClass, uBlock, uAddr, 1);
                }
                //去掉收到数据的空格
                sourceStrHex += receiveStrHex.Replace(" ", "");

                

                //将当前线程休眠5s
                System.Threading.Thread.Sleep(10);

                //开始处理数据
                if (!string.IsNullOrEmpty(sourceStrHex))
                {
                    if (sourceStrHex.Length >= 16)
                    {

                        //处理数据
                        if (sourceStrHex.Length == 82)
                        {

                            //1、解析并显示到界面控件当中
                            AnalyticDataMethod(sourceStrHex);

                            //2/将数据发送到远程服务器上
                            if (MySocket.client != null && MySocket.client.Connected)
                            {
                                //构造通信数据
                                #region MyRegion
                                try
                                {
                                    MySocket.SensorData sd;
                                    string cmd = sourceStrHex;

                                    sd.node = cmd.Substring(0, 16).PadRight(MySocket.MAX_LENGTH_OF_NODE, '\0').ToCharArray();
                                    sd.device = cmd.Substring(16, 2).PadRight(MySocket.MAX_LENGTH_OF_DEVICE, '\0').ToCharArray();
                                    sd.transtype = cmd.Substring(18, 2).PadRight(MySocket.MAX_LENGTH_OF_TRANSTYPE, '\0').ToCharArray();
                                    sd.startaddr = cmd.Substring(20, 4).PadRight(MySocket.MAX_LENGTH_OF_STARTADDR, '\0').ToCharArray();
                                    sd.bytecount = cmd.Substring(24, 2).PadRight(MySocket.MAX_LENGTH_OF_BYTECOUNT, '\0').ToCharArray();
                                    sd.temperature = cmd.Substring(26, 8).PadRight(MySocket.MAX_LENGTH_OF_TEMPERATURE, '\0').ToCharArray();
                                    sd.humidity = cmd.Substring(34, 8).PadRight(MySocket.MAX_LENGTH_OF_HUMIDITY, '\0').ToCharArray();
                                    sd.illuminance = cmd.Substring(42, 8).PadRight(MySocket.MAX_LENGTH_OF_ILLUMINANCE, '\0').ToCharArray();
                                    sd.solitemperature = cmd.Substring(50, 8).PadRight(MySocket.MAX_LENGTH_OF_SOLITEMPERATURE, '\0').ToCharArray();
                                    sd.soliwater = cmd.Substring(58, 8).PadRight(MySocket.MAX_LENGTH_OF_SOLIWATER, '\0').ToCharArray();
                                    sd.voltage = cmd.Substring(66, 8).PadRight(MySocket.MAX_LENGTH_OF_VOLTAGE, '\0').ToCharArray();
                                    sd.checkbit1 = cmd.Substring(74, 4).PadRight(MySocket.MAX_LENGTH_OF_CHECKBIT1, '\0').ToCharArray();
                                    sd.checkbit2 = cmd.Substring(78, 4).PadRight(MySocket.MAX_LENGTH_OF_CHECKBIT2, '\0').ToCharArray();

                                    //将c#托管的数据类型转换成c++的非托管数据类型
                                    byte[] buffer = MySocket.StructureToByte<MySocket.SensorData>(sd);

                                    //发送
                                    MySocket.client.Send(buffer);
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("发送数据至服务器失败！原因" + ex.Message, "提示",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                                #endregion
                            }
                            else
                            {
                                //如果服务器不能连接
                                MessageBox.Show("服务器未建立连接", "提示",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            sourceStrHex = string.Empty;
                        }
                    }
                }
                receiveStrHex = string.Empty;
            }
        }

        //解析数据方法
        private void AnalyticDataMethod(string receiveString)
        {
            ListViewItem istItem = null;//列表控件数据项
            string oldstr = receiveString;
            try
            {
                if (!string.IsNullOrEmpty(receiveString))
                {
                    //解析数据//	 节点地址	                设备地址   传输方式	 起始地址   字节记数  温度           湿度            照度          土壤温度       土壤水份      设备电量        检验1 检验2       
                    //receiveStrHex	 01 1F 01 07 1A D3 00 90     A1        60        00 00      18        01 81 00 E5    02 01 02 B8     03 00 00 A1   04 81 00 E0    05 03 00 08   F2 02 01 48     AF 6B 6E 34
                    istItem = new ListViewItem(DateTime.Now.ToString());//日期
                    istItem.SubItems.Add(receiveString.Substring(0, 16));//节点地址（网关地址）
                    istItem.SubItems.Add(receiveString.Substring(16, 2));//设备地址（传感器地址）
                    if (receiveString.Substring(18, 2) == "60")//网关上传数据的方式(60：主动上传，查询应答上传)
                    {
                        istItem.SubItems.Add("主动上报");
                    }
                    else
                    {
                        istItem.SubItems.Add("查询上报");
                    }
                    //无符号数：0 ----------------- 255
                    //有符号数：-128 --------- 0 ---------- 127　
                    //温度
                    //数据格式 81:10000001
                    if (receiveString.Substring(26, 2) == "01")
                    {
                        //第一组数据:位格式解析
                        double temperature = 0;
                        int pointbit = BitFormat(receiveString.Substring(28, 2));//返回小数位数
                        if (flagBit7 && (!flagBit6) && (!flagBit5) && (!flagBit4))
                        {
                            //flagBit7为true表示是有符号数：温度可能为负数
                            //flagBit6为false表示数值量
                            //flagBit5为false表示用双字节来表示温度
                            //flagBit4为false表示温度取数方式，是取低2字节
                            temperature = Convert.ToInt32(receiveString.Substring(30, 4), 16);//取低2位
                            if (pointbit == 0)
                            { ;}
                            else
                            {
                                //0~7表示小数位数 0：无小数
                                temperature = temperature / (Math.Pow(10, pointbit));
                            }
                        }
                        istItem.SubItems.Add(temperature.ToString() + " °C");
                    }
                    //湿度 
                    //数据格式 01:00000001
                    if (receiveString.Substring(34, 2) == "02")
                    {
                        //第二组数据:位格式解析
                        double humidity = 0;
                        int pointbit = BitFormat(receiveString.Substring(36, 2));//返回小数位数
                        if ((!flagBit7) && (!flagBit6) && (!flagBit5) && (!flagBit4))
                        {
                            //flagBit7为false表示是无符号数：湿度为非负数
                            //flagBit6为false表示数值量
                            //flagBit5为false表示用双字节来表示湿度
                            //flagBit4为false表示湿度取数方式，是取低2字节
                            humidity = Convert.ToInt32(receiveString.Substring(38, 4), 16);//取低2位
                            if (pointbit == 0)
                            { ;}
                            else
                            {
                                //0~7表示小数位数 0：无小数
                                humidity = humidity / (Math.Pow(10, pointbit));
                            }
                        }
                        istItem.SubItems.Add(humidity.ToString() + " %RH");
                    }
                    //照度 
                    //数据格式 00:00000000
                    if (receiveString.Substring(42, 2) == "03")
                    {
                        //第三组数据:位格式解析
                        double illuminance = 0;
                        int pointbit = BitFormat(receiveString.Substring(44, 2));//返回小数位数
                        if ((!flagBit7) && (!flagBit6) && (!flagBit5) && (!flagBit4))
                        {
                            //flagBit7为false表示是无符号数:照度为非负数
                            //flagBit6为false表示数值量
                            //flagBit5为false表示用双字节来表示照度
                            //flagBit4为false表示照度取数方式，是取低2字节
                            illuminance = Convert.ToInt32(receiveString.Substring(46, 4), 16);//取低2位
                            if (pointbit == 0)
                            { ;}
                            else
                            {
                                //0~7表示小数位数 0：无小数
                                illuminance = illuminance / (Math.Pow(10, pointbit));
                            }
                        }
                        istItem.SubItems.Add(illuminance.ToString() + " lux");
                    }
                    //土壤温度
                    //数据格式 81:10000001
                    if (receiveString.Substring(50, 2) == "04")
                    {
                        //第四组数据:位格式解析
                        double soliTemperature = 0;
                        int pointbit = BitFormat(receiveString.Substring(52, 2));//返回小数位数
                        if (flagBit7 && (!flagBit6) && (!flagBit5) && (!flagBit4))
                        {
                            //flagBit7为true表示是有符号数：土壤温度可能为负数
                            //flagBit6为false表示数值量
                            //flagBit5为false表示用双字节来表示土壤温度
                            //flagBit4为false表示土壤温度取数方式，是取低2字节
                            soliTemperature = Convert.ToInt32(receiveString.Substring(54, 4), 16);//取低2位
                            if (pointbit == 0)
                            { ;}
                            else
                            {
                                //0~7表示小数位数 0：无小数
                                soliTemperature = soliTemperature / (Math.Pow(10, pointbit));
                            }
                        }
                        istItem.SubItems.Add(soliTemperature.ToString() + " °C");
                    }
                    //土壤水份
                    //数据格式 03:00000011
                    if (receiveString.Substring(58, 2) == "05")
                    {
                        //第五组数据:位格式解析
                        double soliWater = 0;
                        int pointbit = BitFormat(receiveString.Substring(60, 2));//返回小数位数
                        if ((!flagBit7) && (!flagBit6) && (!flagBit5) && (!flagBit4))
                        {
                            //flagBit7为false表示是无符号数：土壤水份为非负数
                            //flagBit6为false表示数值量
                            //flagBit5为false表示用双字节来表示土壤水份
                            //flagBit4为false表示土壤水份取数方式，是取低2字节
                            soliWater = Convert.ToInt32(receiveString.Substring(62, 4), 16);//取低2位
                            if (pointbit == 0)
                            { ;}
                            else
                            {
                                //0~7表示小数位数 0：无小数
                                soliWater = soliWater / (Math.Pow(10, pointbit));
                            }
                            istItem.SubItems.Add(soliWater + " V");
                        }
                    }
                    //设备电量
                    //数据格式 02:00000010
                    if (receiveString.Substring(66, 2) == "F2")
                    {
                        //第六组数据:位格式解析
                        double voltage = 0;
                        int pointbit = BitFormat(receiveString.Substring(68, 2));//返回小数位数
                        if ((!flagBit7) && (!flagBit6) && (!flagBit5) && (!flagBit4))
                        {
                            //flagBit7为false表示是无符号数：电量为非负数
                            //flagBit6为false表示数值量
                            //flagBit5为false表示用双字节来表示电量
                            //flagBit4为false表示电量取数方式，是取低2字节
                            voltage = Convert.ToInt32(receiveString.Substring(70, 4), 16);//取低2位
                            if (pointbit == 0)
                            { ;}
                            else
                            {
                                //0~7表示小数位数 0：无小数
                                voltage = voltage / (Math.Pow(10, pointbit));
                            }
                        }
                        istItem.SubItems.Add(voltage.ToString() + " V");
                    }

                    //委托到显示数据方法(脱离UI线程,防止界面因非UI线程访问而被卡死)
                    if (this.lstvData.InvokeRequired)
                    {
                        this.lstvData.Invoke(new MethodInvoker(delegate() { UpdateReceiveDataFun(istItem); }));
                    }
                    else
                    {
                        //更新数据并显示到ListView表格中
                        UpdateReceiveDataFun(istItem);
                    }

                }
            }
            catch (Exception ea)
            {
                string msg = ea.Message;
                MessageBox.Show("解析出错：" + msg + " ；收到数据：" + oldstr, "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //解析数据格式位（8个bit,见数据格式位地址说明表）,返回小数点位数
        private int BitFormat(string bitStrHex)
        {
            ClearFlag();
            //将十六进制bitStrHex转换成二进制数
            int decStr = Convert.ToInt32(bitStrHex.ToString(), 16);//先转成十进制
            string binStr = Convert.ToString(decStr, 2); //再将十进制转成二进制
            //PadLeft(int totalWidth, char paddingChar) //在字符串左边用 paddingChar 补足 totalWidth 长度
            binStr = binStr.PadLeft(8, '0'); //不够8位，从左边补0，最终对齐8位
            char[] bitCharArray = binStr.ToCharArray();//8位二进制字符串转成字符数组
            //最后三位二进制位表示小数位数
            string last3bit = string.Empty;
            //数据格式 81:10000001
            for (int i = 0; i < bitCharArray.Length; i++)
            {
                if (i == 0 && bitCharArray[i] == '1')
                {
                    flagBit7 = true;
                }
                if (i == 1 && bitCharArray[i] == '1')
                {
                    flagBit6 = true;
                }
                if (i == 2 && bitCharArray[i] == '1')
                {
                    flagBit5 = true;
                }
                if (i == 3 && bitCharArray[i] == '1')
                {
                    flagBit4 = true;
                }
                if (i == 4 && bitCharArray[i] == '1')
                {
                    //就是协议里的Bit4(第5位，存是具体的数据的值)
                }
                //最后三位表示小数位
                if (i == 5)
                {
                    last3bit += bitCharArray[i].ToString();
                }
                if (i == 6)
                {
                    last3bit += bitCharArray[i].ToString();
                }
                if (i == 7)
                {
                    last3bit += bitCharArray[i].ToString();
                }
            }
            //将最后三位二进制位 转成 十进制数(小数点位数)返回
            return Convert.ToInt32(last3bit, 2);
        }
        //重置数据格式位全局标志
        private void ClearFlag()
        {
            flagBit7 = false;//是否是无符号数：True有符号数 false无符号数
            flagBit6 = false;//是否是数值:True开关量 false数值
            flagBit5 = false;//长整形数值标识:True四字节 false双字节
            flagBit4 = false;//四字节数字节标识:True高两字节 false低两字节
        }
        //将数据显示到ListView中
        private void UpdateReceiveDataFun(ListViewItem item)
        {
            //先把UI挂起，避免多次加载数据时给用户造成闪屏
            lstvData.BeginUpdate();
            //添加数据子项
            lstvData.Items.Add(item);
            //结束，一次性刷新控件
            lstvData.EndUpdate();

        }

        //主动上报复选框的状态改变事件
        private void chkAutoRequest_CheckedChanged(object sender, EventArgs e)
        {
            //检查设备是否在线
            if (CheckIsOnline())
            {
                if (chkAutoRequest.Checked)
                {
                    if (MySocket.gateWayUploadDataType == "主动上报")
                    {
                        //取消查询应答复选框的选中状态
                        chkRequest.Checked = false;
                        //实例化一个采集网关主动上报数据的线程
                        receiveThd = new Thread(new ThreadStart(ReceiveMsg));
                        receiveThd.Start();//启动
                    }
                    else
                    {
                        MessageBox.Show("网关配置：上报数据方式不支持主动上报", "提示",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        chkAutoRequest.Checked = false;//取消选中主动上报复选框
                        return;
                    }
                }
                else
                {
                    //停止接收线程
                    AbortReceiveThd();
                }
            }
            else
            {
                //停止接收线程
                AbortReceiveThd();
                MessageBox.Show("网关设备离线！（请检查网关是否连接或设备状态）", "提示",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //查询应答复选框的状态改变事件
        private void chkRequest_CheckedChanged(object sender, EventArgs e)
        {
            //查检设备是否在线
            if (CheckIsOnline())
            {
                if (chkRequest.Checked)
                {
                    if (MySocket.gateWayUploadDataType == "查询应答")
                    {
                        //取消主动上报复选框的选中状态
                        chkAutoRequest.Checked = false;

                        //实例化一个接收数据线程
                        receiveThdByManual = new Thread(new ThreadStart(ReceiveMsg));
                        receiveThdByManual.IsBackground = true;
                        receiveThdByManual.Start();
                    }
                    else
                    {
                        MessageBox.Show("网关配置：上报数据方式不支持,查询应答", "提示",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        chkRequest.Checked = false;//取消选中查询应答复选框
                        return;
                    }
                }
                else
                {
                    //停止接收线程
                    AbortReceiveThd();
                }
            }
            else
            {
                //停止接收线程
                AbortReceiveThd();
                MessageBox.Show("网关设备离线！（请检查网关是否连接或设备状态）", "提示",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //监听网关复选框的状态改变事件
        private void chkGateWayListener_CheckedChanged(object sender, EventArgs e)
        {
            if (chkGateWayListener.Checked)
            {
                //启动定时器
                isOnlineGateWayTm = new System.Threading.Timer(new TimerCallback(IsOnlineGateWayTmFun), this, 0,
                    5000);//5s监听一次
            }
            else
            {
                if (isOnlineGateWayTm != null)
                {
                    isOnlineGateWayTm.Dispose();//停止定时器

                }
            }
        }
        //监听网关是否在线的函数
        private void IsOnlineGateWayTmFun(object obj)
        {
            bool flag = CheckIsOnline();
            if (flag)
            {
                //根据网关配置中数据上报的方式来确定用哪种方式接受数据
                if (MySocket.gateWayUploadDataType == "主动上报")
                {
                    chkAutoRequest.Checked = true;
                }
                else if (MySocket.gateWayUploadDataType == "查询应答")
                {
                    chkRequest.Checked = true;
                }
            }
        }
        //窗体首次加载事件
        private void SensorsMonitor_Load(object sender, EventArgs e)
        {
            BtnStatusByStopService();
        }
        //窗体关闭后事件
        private void SensorsMonitor_FormClosed(object sender, FormClosedEventArgs e)
        {
            //结束接受数据的线程
            AbortReceiveThd();
            AbortReceiveThdByManul();
            //关闭Socket
            if (MySocket.client != null)
            {
                try
                {
                    MySocket.client.Disconnect(true);
                    MySocket.client.Close(10);//如果有未处理完的数据，延时10s才关闭Socket
                }
                catch (Exception)
                {
                }
            }
            Application.Exit();
        }
        //终止接受数据线程：主动上报
        private void AbortReceiveThd()
        {
            if (receiveThd != null && receiveThd.IsAlive)
            {
                try
                {
                    receiveThd.Abort();
                }
                catch (Exception)
                {
                }
            }
        }
        //终止接受数据线程：查询应答
        private void AbortReceiveThdByManul()
        {
            if (receiveThdByManual != null && receiveThdByManual.IsAlive)
            {
                try
                {
                    receiveThdByManual.Abort();
                }
                catch (Exception)
                {
                }
            }
        }
    }
}
