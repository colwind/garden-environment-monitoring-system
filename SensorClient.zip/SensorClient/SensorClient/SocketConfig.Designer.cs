﻿namespace SensorClient
{
    partial class SocketConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtIP = new System.Windows.Forms.TextBox();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.txtSendCmd = new System.Windows.Forms.TextBox();
            this.prbStatus = new System.Windows.Forms.ProgressBar();
            this.txtReceiveCmd = new System.Windows.Forms.TextBox();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnSend = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnStopConnect = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "远程服务器IP地址：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(82, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "服务器端口：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(82, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "服务器连接状态：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(82, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "测试数据：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(82, 259);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "收到的数据：";
            // 
            // txtIP
            // 
            this.txtIP.Location = new System.Drawing.Point(193, 44);
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new System.Drawing.Size(100, 21);
            this.txtIP.TabIndex = 5;
            this.txtIP.Text = "192.168.10.78";
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(193, 91);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(100, 21);
            this.txtPort.TabIndex = 6;
            this.txtPort.Text = "8888";
            // 
            // txtSendCmd
            // 
            this.txtSendCmd.Location = new System.Drawing.Point(193, 202);
            this.txtSendCmd.Name = "txtSendCmd";
            this.txtSendCmd.Size = new System.Drawing.Size(391, 21);
            this.txtSendCmd.TabIndex = 7;
            this.txtSendCmd.Text = "011F01071AD30090A160000018018100E5020102B8030000A1048100E005030008F2020148AF6B6E3" +
    "4";
            // 
            // prbStatus
            // 
            this.prbStatus.ForeColor = System.Drawing.Color.Red;
            this.prbStatus.Location = new System.Drawing.Point(193, 165);
            this.prbStatus.MarqueeAnimationSpeed = 0;
            this.prbStatus.Name = "prbStatus";
            this.prbStatus.Size = new System.Drawing.Size(294, 23);
            this.prbStatus.Step = 1;
            this.prbStatus.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.prbStatus.TabIndex = 8;
            // 
            // txtReceiveCmd
            // 
            this.txtReceiveCmd.Location = new System.Drawing.Point(193, 249);
            this.txtReceiveCmd.Multiline = true;
            this.txtReceiveCmd.Name = "txtReceiveCmd";
            this.txtReceiveCmd.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtReceiveCmd.Size = new System.Drawing.Size(391, 98);
            this.txtReceiveCmd.TabIndex = 9;
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(193, 370);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(107, 23);
            this.btnclear.TabIndex = 10;
            this.btnclear.Text = "清空接收数据";
            this.btnclear.UseVisualStyleBackColor = true;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(356, 369);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(102, 23);
            this.btnSend.TabIndex = 11;
            this.btnSend.Text = "手动发送数据";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(193, 119);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 12;
            this.btnConnect.Text = "建立连接";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnStopConnect
            // 
            this.btnStopConnect.Location = new System.Drawing.Point(298, 119);
            this.btnStopConnect.Name = "btnStopConnect";
            this.btnStopConnect.Size = new System.Drawing.Size(75, 23);
            this.btnStopConnect.TabIndex = 13;
            this.btnStopConnect.Text = "断开连接";
            this.btnStopConnect.UseVisualStyleBackColor = true;
            this.btnStopConnect.Click += new System.EventHandler(this.btnStopConnect_Click);
            // 
            // SocketConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 432);
            this.Controls.Add(this.btnStopConnect);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.txtReceiveCmd);
            this.Controls.Add(this.prbStatus);
            this.Controls.Add(this.txtSendCmd);
            this.Controls.Add(this.txtPort);
            this.Controls.Add(this.txtIP);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SocketConfig";
            this.Text = "远程服务器连接配置";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SocketConfig_FormClosed);
            this.Load += new System.EventHandler(this.SocketConfig_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtIP;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.TextBox txtSendCmd;
        private System.Windows.Forms.ProgressBar prbStatus;
        private System.Windows.Forms.TextBox txtReceiveCmd;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnStopConnect;
    }
}