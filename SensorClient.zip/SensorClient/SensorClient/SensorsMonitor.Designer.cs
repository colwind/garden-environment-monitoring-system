﻿namespace SensorClient
{
    partial class SensorsMonitor
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SensorsMonitor));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tlsServerConfig = new System.Windows.Forms.ToolStripMenuItem();
            this.tlsGateWayConfig = new System.Windows.Forms.ToolStripMenuItem();
            this.btnStartService = new System.Windows.Forms.Button();
            this.btnStopService = new System.Windows.Forms.Button();
            this.bteCheckServer = new System.Windows.Forms.Button();
            this.btnIsOnline = new System.Windows.Forms.Button();
            this.chkAutoRequest = new System.Windows.Forms.CheckBox();
            this.chkRequest = new System.Windows.Forms.CheckBox();
            this.chkGateWayListener = new System.Windows.Forms.CheckBox();
            this.pbGateWay = new System.Windows.Forms.PictureBox();
            this.lstvData = new System.Windows.Forms.ListView();
            this.colRDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNodeAddr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSensorsAddr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTranType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTemperature = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colHumidity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colIlluminance = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSoliTemperature = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSoliWater = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colVoltage = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbGateWay)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlsServerConfig,
            this.tlsGateWayConfig});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(984, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tlsServerConfig
            // 
            this.tlsServerConfig.Name = "tlsServerConfig";
            this.tlsServerConfig.Size = new System.Drawing.Size(104, 21);
            this.tlsServerConfig.Text = "服务器链接配置";
            this.tlsServerConfig.Click += new System.EventHandler(this.tlsServerConfig_Click);
            // 
            // tlsGateWayConfig
            // 
            this.tlsGateWayConfig.Name = "tlsGateWayConfig";
            this.tlsGateWayConfig.Size = new System.Drawing.Size(68, 21);
            this.tlsGateWayConfig.Text = "网关配置";
            this.tlsGateWayConfig.Click += new System.EventHandler(this.tlsGateWayConfig_Click);
            // 
            // btnStartService
            // 
            this.btnStartService.Location = new System.Drawing.Point(12, 39);
            this.btnStartService.Name = "btnStartService";
            this.btnStartService.Size = new System.Drawing.Size(75, 23);
            this.btnStartService.TabIndex = 1;
            this.btnStartService.Text = "启动服务";
            this.btnStartService.UseVisualStyleBackColor = true;
            this.btnStartService.Click += new System.EventHandler(this.btnStartService_Click);
            // 
            // btnStopService
            // 
            this.btnStopService.Location = new System.Drawing.Point(133, 39);
            this.btnStopService.Name = "btnStopService";
            this.btnStopService.Size = new System.Drawing.Size(75, 23);
            this.btnStopService.TabIndex = 2;
            this.btnStopService.Text = "停止服务";
            this.btnStopService.UseVisualStyleBackColor = true;
            this.btnStopService.Click += new System.EventHandler(this.btnStopService_Click);
            // 
            // bteCheckServer
            // 
            this.bteCheckServer.Location = new System.Drawing.Point(254, 39);
            this.bteCheckServer.Name = "bteCheckServer";
            this.bteCheckServer.Size = new System.Drawing.Size(75, 23);
            this.bteCheckServer.TabIndex = 3;
            this.bteCheckServer.Text = "检查服务器";
            this.bteCheckServer.UseVisualStyleBackColor = true;
            this.bteCheckServer.Click += new System.EventHandler(this.bteCheckServer_Click);
            // 
            // btnIsOnline
            // 
            this.btnIsOnline.Location = new System.Drawing.Point(375, 39);
            this.btnIsOnline.Name = "btnIsOnline";
            this.btnIsOnline.Size = new System.Drawing.Size(75, 23);
            this.btnIsOnline.TabIndex = 4;
            this.btnIsOnline.Text = "检查网关";
            this.btnIsOnline.UseVisualStyleBackColor = true;
            this.btnIsOnline.Click += new System.EventHandler(this.btnIsOnline_Click);
            // 
            // chkAutoRequest
            // 
            this.chkAutoRequest.AutoSize = true;
            this.chkAutoRequest.Location = new System.Drawing.Point(492, 43);
            this.chkAutoRequest.Name = "chkAutoRequest";
            this.chkAutoRequest.Size = new System.Drawing.Size(72, 16);
            this.chkAutoRequest.TabIndex = 5;
            this.chkAutoRequest.Text = "主动上报";
            this.chkAutoRequest.UseVisualStyleBackColor = true;
            this.chkAutoRequest.CheckedChanged += new System.EventHandler(this.chkAutoRequest_CheckedChanged);
            // 
            // chkRequest
            // 
            this.chkRequest.AutoSize = true;
            this.chkRequest.Location = new System.Drawing.Point(612, 43);
            this.chkRequest.Name = "chkRequest";
            this.chkRequest.Size = new System.Drawing.Size(72, 16);
            this.chkRequest.TabIndex = 6;
            this.chkRequest.Text = "查询应答";
            this.chkRequest.UseVisualStyleBackColor = true;
            this.chkRequest.CheckedChanged += new System.EventHandler(this.chkRequest_CheckedChanged);
            // 
            // chkGateWayListener
            // 
            this.chkGateWayListener.AutoSize = true;
            this.chkGateWayListener.Location = new System.Drawing.Point(732, 43);
            this.chkGateWayListener.Name = "chkGateWayListener";
            this.chkGateWayListener.Size = new System.Drawing.Size(72, 16);
            this.chkGateWayListener.TabIndex = 7;
            this.chkGateWayListener.Text = "监听网关";
            this.chkGateWayListener.UseVisualStyleBackColor = true;
            this.chkGateWayListener.CheckedChanged += new System.EventHandler(this.chkGateWayListener_CheckedChanged);
            // 
            // pbGateWay
            // 
            this.pbGateWay.Image = global::SensorClient.Properties.Resources.unknow;
            this.pbGateWay.Location = new System.Drawing.Point(837, 29);
            this.pbGateWay.Name = "pbGateWay";
            this.pbGateWay.Size = new System.Drawing.Size(33, 33);
            this.pbGateWay.TabIndex = 8;
            this.pbGateWay.TabStop = false;
            // 
            // lstvData
            // 
            this.lstvData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstvData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colRDate,
            this.colNodeAddr,
            this.colSensorsAddr,
            this.colTranType,
            this.colTemperature,
            this.colHumidity,
            this.colIlluminance,
            this.colSoliTemperature,
            this.colSoliWater,
            this.colVoltage});
            this.lstvData.GridLines = true;
            this.lstvData.Location = new System.Drawing.Point(12, 86);
            this.lstvData.Name = "lstvData";
            this.lstvData.Size = new System.Drawing.Size(938, 431);
            this.lstvData.TabIndex = 9;
            this.lstvData.UseCompatibleStateImageBehavior = false;
            this.lstvData.View = System.Windows.Forms.View.Details;
            // 
            // colRDate
            // 
            this.colRDate.Text = "日期";
            this.colRDate.Width = 140;
            // 
            // colNodeAddr
            // 
            this.colNodeAddr.Text = "传感器节点地址";
            this.colNodeAddr.Width = 130;
            // 
            // colSensorsAddr
            // 
            this.colSensorsAddr.Text = "传感器通信地址";
            this.colSensorsAddr.Width = 130;
            // 
            // colTranType
            // 
            this.colTranType.Text = "传输方式";
            this.colTranType.Width = 80;
            // 
            // colTemperature
            // 
            this.colTemperature.Text = "温度";
            this.colTemperature.Width = 80;
            // 
            // colHumidity
            // 
            this.colHumidity.Text = "湿度";
            this.colHumidity.Width = 80;
            // 
            // colIlluminance
            // 
            this.colIlluminance.Text = "光照度";
            this.colIlluminance.Width = 80;
            // 
            // colSoliTemperature
            // 
            this.colSoliTemperature.Text = "土壤温度";
            this.colSoliTemperature.Width = 80;
            // 
            // colSoliWater
            // 
            this.colSoliWater.Text = "土壤水分";
            this.colSoliWater.Width = 80;
            // 
            // colVoltage
            // 
            this.colVoltage.Text = "设备电量";
            this.colVoltage.Width = 80;
            // 
            // SensorsMonitor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 529);
            this.Controls.Add(this.lstvData);
            this.Controls.Add(this.pbGateWay);
            this.Controls.Add(this.chkGateWayListener);
            this.Controls.Add(this.chkRequest);
            this.Controls.Add(this.chkAutoRequest);
            this.Controls.Add(this.btnIsOnline);
            this.Controls.Add(this.bteCheckServer);
            this.Controls.Add(this.btnStopService);
            this.Controls.Add(this.btnStartService);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "SensorsMonitor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "                                                                                 " +
    "         温室花卉环境信息智能监测系统";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SensorsMonitor_FormClosed);
            this.Load += new System.EventHandler(this.SensorsMonitor_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbGateWay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tlsServerConfig;
        private System.Windows.Forms.ToolStripMenuItem tlsGateWayConfig;
        private System.Windows.Forms.Button btnStartService;
        private System.Windows.Forms.Button btnStopService;
        private System.Windows.Forms.Button bteCheckServer;
        private System.Windows.Forms.Button btnIsOnline;
        private System.Windows.Forms.CheckBox chkAutoRequest;
        private System.Windows.Forms.CheckBox chkRequest;
        private System.Windows.Forms.CheckBox chkGateWayListener;
        private System.Windows.Forms.PictureBox pbGateWay;
        private System.Windows.Forms.ListView lstvData;
        private System.Windows.Forms.ColumnHeader colRDate;
        private System.Windows.Forms.ColumnHeader colNodeAddr;
        private System.Windows.Forms.ColumnHeader colSensorsAddr;
        private System.Windows.Forms.ColumnHeader colTranType;
        private System.Windows.Forms.ColumnHeader colTemperature;
        private System.Windows.Forms.ColumnHeader colHumidity;
        private System.Windows.Forms.ColumnHeader colIlluminance;
        private System.Windows.Forms.ColumnHeader colSoliTemperature;
        private System.Windows.Forms.ColumnHeader colSoliWater;
        private System.Windows.Forms.ColumnHeader colVoltage;
    }
}

