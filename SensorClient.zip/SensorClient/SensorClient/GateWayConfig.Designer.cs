﻿namespace SensorClient
{
    partial class GateWayConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtGateWayIP = new System.Windows.Forms.TextBox();
            this.txtGateWayPort = new System.Windows.Forms.TextBox();
            this.txtGateWaySeriaNumber = new System.Windows.Forms.TextBox();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.cbxUploadType = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(62, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "网关IP地址：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(62, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "网关端口：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(62, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "网关序列号：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(62, 181);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "上报数据方式：";
            // 
            // txtGateWayIP
            // 
            this.txtGateWayIP.Location = new System.Drawing.Point(175, 50);
            this.txtGateWayIP.Name = "txtGateWayIP";
            this.txtGateWayIP.Size = new System.Drawing.Size(121, 21);
            this.txtGateWayIP.TabIndex = 4;
            this.txtGateWayIP.Text = "192.168.10.77";
            // 
            // txtGateWayPort
            // 
            this.txtGateWayPort.Location = new System.Drawing.Point(175, 88);
            this.txtGateWayPort.Name = "txtGateWayPort";
            this.txtGateWayPort.Size = new System.Drawing.Size(121, 21);
            this.txtGateWayPort.TabIndex = 5;
            this.txtGateWayPort.Text = "8000";
            // 
            // txtGateWaySeriaNumber
            // 
            this.txtGateWaySeriaNumber.Location = new System.Drawing.Point(175, 132);
            this.txtGateWaySeriaNumber.Name = "txtGateWaySeriaNumber";
            this.txtGateWaySeriaNumber.Size = new System.Drawing.Size(121, 21);
            this.txtGateWaySeriaNumber.TabIndex = 6;
            this.txtGateWaySeriaNumber.Text = "6.20.11";
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(62, 240);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 7;
            this.btnsave.Text = "保存";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(221, 240);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(75, 23);
            this.btnclear.TabIndex = 8;
            this.btnclear.Text = "清空";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // cbxUploadType
            // 
            this.cbxUploadType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxUploadType.FormattingEnabled = true;
            this.cbxUploadType.Items.AddRange(new object[] {
            "主动上报",
            "查询应答"});
            this.cbxUploadType.Location = new System.Drawing.Point(175, 181);
            this.cbxUploadType.Name = "cbxUploadType";
            this.cbxUploadType.Size = new System.Drawing.Size(121, 20);
            this.cbxUploadType.TabIndex = 9;
            // 
            // GateWayConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 334);
            this.Controls.Add(this.cbxUploadType);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.txtGateWaySeriaNumber);
            this.Controls.Add(this.txtGateWayPort);
            this.Controls.Add(this.txtGateWayIP);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GateWayConfig";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "网关参数配置";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.GateWayConfig_FormClosed);
            this.Load += new System.EventHandler(this.GateWayConfig_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtGateWayIP;
        private System.Windows.Forms.TextBox txtGateWayPort;
        private System.Windows.Forms.TextBox txtGateWaySeriaNumber;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.ComboBox cbxUploadType;
    }
}