﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;

namespace SensorClient
{
    public partial class SocketConfig : Form
    {

        //接收线程
        private Thread th = null;
        public SocketConfig()
        {
            InitializeComponent();
        }
        //清空接收数据文本框
        private void btnClear_Click(object sender, EventArgs e)
        {          
            txtReceiveCmd.Text = string.Empty;
        }       
        //建立连接
        private void btnConnect_Click(object sender, EventArgs e)
        {
            #region MyRegion
            //目标服务器IP
            IPAddress ip;
            if (!IPAddress.TryParse(txtIP.Text, out ip))
            {
                MessageBox.Show("远程服务器IP地址错误！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                MySocket.remoteHostIP = txtIP.Text;
            }
            //定义化一个网络终结点对象
            IPEndPoint point;
            try
            {
                MySocket.remotePort = int.Parse(txtPort.Text);
                //实例化结点对象
                point = new IPEndPoint(ip, MySocket.remotePort);
            }
            catch (Exception)
            {
                MessageBox.Show("远程服务器端口错误！", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //测试与远程服务器是否连接
            Ping ping = new Ping();
            PingReply reply = null;
            try
            {
                reply = ping.Send(IPAddress.Parse(MySocket.remoteHostIP), 3000);
            }
            catch (Exception)
            {
                //控制界面其它控件的状态
                BtnStopConnect();
                MessageBox.Show("远程服务器没有响应！", "提示",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            } 
            #endregion

            if (reply != null && reply.Status == IPStatus.Success)
            {
                #region MyRegion
                try
                {
                    //实例化一个客户端Socket
                    MySocket.client = new Socket(AddressFamily.InterNetwork, SocketType.Stream,
                        ProtocolType.Tcp);
                    //连接服务器
                    MySocket.client.Connect(point);
                    MessageBox.Show("连接服务器成功！服务器：" + MySocket.client.RemoteEndPoint.ToString() +
                    "\r\n客户端：" + MySocket.client.LocalEndPoint.ToString(),
                        "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //控制界面控件的状态
                    BtnConnect();
                    //更新界面进度条状态
                    if (this.prbStatus.InvokeRequired)
                    {
                        //异步
                        this.prbStatus.Invoke(new MethodInvoker(
                            delegate() { UpdateProgressBarStatus(IPStatus.Success); }));

                    }
                    else
                    {
                        UpdateProgressBarStatus(IPStatus.Success);
                    }
                    //连接成功后，开始一个线程来随时接收服务器数据
                    th = new Thread(ReceiveMsg);
                    th.IsBackground = true;
                    th.Start();                       

                }
                catch (Exception ex)
                {
                    //控制界面控件的状态
                    BtnStopConnect();
                    //更新界面进度条状态
                    if (this.prbStatus.InvokeRequired)
                    {
                        //异步
                        this.prbStatus.Invoke(new MethodInvoker(
                            delegate() { UpdateProgressBarStatus(IPStatus.TimedOut); }));

                    }
                    else
                    {
                        UpdateProgressBarStatus(IPStatus.TimedOut);
                    }

                    MessageBox.Show("建立连接失败！原因：" + ex.Message, "提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                } 
                #endregion
            }
            else
            {
                //控制界面其它控件的状态
                BtnStopConnect();
                MessageBox.Show("远程服务器没有响应！", "提示",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //断开连接
        private void btnStopConnect_Click(object sender, EventArgs e)
        {
            if (MySocket.client != null)
            {
                //停止接收数据线程
                if (th != null || th.ThreadState == ThreadState.Running)
                {
                    try
                    {
                        th.Abort();
                    }
                    catch (Exception)
                    {
                    }
                }

                try
                {
                    MySocket.client.Disconnect(true);
                    MySocket.client.Close(10);

                    //未连接成功状态
                    BtnStopConnect();
                    //更新界面进度条状态
                    if (this.prbStatus.InvokeRequired)
                    {
                        //异步
                        this.prbStatus.Invoke(new MethodInvoker(
                            delegate() { UpdateProgressBarStatus(IPStatus.TimedOut); }));

                    }
                    else
                    {
                        UpdateProgressBarStatus(IPStatus.TimedOut);
                    }

                    MessageBox.Show("服务器已断开连接！",
                       "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("断开连接出错！原因：" + ex.Message,
                        "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }
        //接收数据的函数
        private void ReceiveMsg()
        {
            while (true)
            {
                
                byte []buffer = new byte[1024*1024];

                //收数据
                int n = MySocket.client.Receive(buffer);
                //将c++的非托管数据类型转换成 c#托管的数据类型
                MySocket.SensorData sd = MySocket.ByteToStructure<MySocket.SensorData>(buffer);

                //将当前线程休眠1s
                System.Threading.Thread.Sleep(1000);
                if (n > 0)
                {
                    //异步更新: 非UI线程要去动态的更新UI线程创建的控件的值，用同步方法控件就会失去响应
                    if (this.txtReceiveCmd.InvokeRequired)
                    {
                        //异步
                        this.txtReceiveCmd.Invoke(new MethodInvoker(
                            delegate() { ShowMsg(MySocket.client.RemoteEndPoint.ToString(), sd); }));

                    }
                    else
                    {
                        //同步
                        ShowMsg(MySocket.client.RemoteEndPoint.ToString(), sd);
                    }
                }
            }
        }
        //未连接成功状态
        private void BtnStopConnect()
        {
            btnStopConnect.Enabled = false;//禁用
            btnConnect.Enabled = true;//启用
            btnSend.Enabled = false;//禁用
        }
        //已连接成功状态
        private void BtnConnect()
        {
            btnStopConnect.Enabled = true;//启用
            btnConnect.Enabled = false;//禁用
            btnSend.Enabled = true;//启用
        }
        //更新界面进度条状态
        private void UpdateProgressBarStatus(IPStatus status)
        {
            if (status == IPStatus.Success)
            {
                prbStatus.MarqueeAnimationSpeed = 100;
                prbStatus.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                prbStatus.MarqueeAnimationSpeed = 0;
                prbStatus.ForeColor = System.Drawing.Color.Red;
            }
        } 
        //显示接收数据的方法
        private void ShowMsg(string remoteIP,MySocket.SensorData sd)
        {
            //解析数据
            if (Marshal.SizeOf(sd) > 0)
            {
                txtReceiveCmd.AppendText(remoteIP + ": ");
                txtReceiveCmd.AppendText(new string(sd.node));
                txtReceiveCmd.AppendText(new string(sd.device));
                txtReceiveCmd.AppendText(new string(sd.transtype));
                txtReceiveCmd.AppendText(new string(sd.startaddr));
                txtReceiveCmd.AppendText(new string(sd.bytecount));
                txtReceiveCmd.AppendText(new string(sd.temperature));
                txtReceiveCmd.AppendText(new string(sd.humidity));
                txtReceiveCmd.AppendText(new string(sd.illuminance));
                txtReceiveCmd.AppendText(new string(sd.solitemperature));
                txtReceiveCmd.AppendText(new string(sd.soliwater));
                txtReceiveCmd.AppendText(new string(sd.voltage));
                txtReceiveCmd.AppendText(new string(sd.checkbit1));
                txtReceiveCmd.AppendText(new string(sd.checkbit1));
                txtReceiveCmd.AppendText("\r\n");//换行符
            }
        }
        //手动发送数据
        private void btnSend_Click(object sender, EventArgs e)
        {
            if (MySocket.client != null && MySocket.client.Connected)
            {
                try
                {
                    //准备数据
                    string cmd = txtSendCmd.Text;

                    //构建一个通信数据的结构体对象
                    MySocket.SensorData sd;
                    sd.node = cmd.Substring(0, 16).PadRight(MySocket.MAX_LENGTH_OF_NODE, '\0').ToCharArray();
                    sd.device = cmd.Substring(16, 2).PadRight(MySocket.MAX_LENGTH_OF_DEVICE, '\0').ToCharArray();
                    sd.transtype = cmd.Substring(18, 2).PadRight(MySocket.MAX_LENGTH_OF_TRANSTYPE, '\0').ToCharArray();
                    sd.startaddr = cmd.Substring(20, 4).PadRight(MySocket.MAX_LENGTH_OF_STARTADDR, '\0').ToCharArray();
                    sd.bytecount = cmd.Substring(24, 2).PadRight(MySocket.MAX_LENGTH_OF_BYTECOUNT, '\0').ToCharArray();
                    sd.temperature = cmd.Substring(26, 8).PadRight(MySocket.MAX_LENGTH_OF_TEMPERATURE, '\0').ToCharArray();
                    sd.humidity = cmd.Substring(34, 8).PadRight(MySocket.MAX_LENGTH_OF_HUMIDITY, '\0').ToCharArray();
                    sd.illuminance = cmd.Substring(42, 8).PadRight(MySocket.MAX_LENGTH_OF_ILLUMINANCE, '\0').ToCharArray();
                    sd.solitemperature = cmd.Substring(50, 8).PadRight(MySocket.MAX_LENGTH_OF_SOLITEMPERATURE, '\0').ToCharArray();
                    sd.soliwater = cmd.Substring(58, 8).PadRight(MySocket.MAX_LENGTH_OF_SOLIWATER, '\0').ToCharArray();
                    sd.voltage = cmd.Substring(66, 8).PadRight(MySocket.MAX_LENGTH_OF_VOLTAGE, '\0').ToCharArray();
                    sd.checkbit1 = cmd.Substring(74, 4).PadRight(MySocket.MAX_LENGTH_OF_CHECKBIT1, '\0').ToCharArray();
                    sd.checkbit2 = cmd.Substring(78, 4).PadRight(MySocket.MAX_LENGTH_OF_CHECKBIT2, '\0').ToCharArray();


                    //将c#托管的数据类型转换成c++的非托管数据类型
                    byte[] buffer = MySocket.StructureToByte<MySocket.SensorData>(sd);

                    //发送
                    MySocket.client.Send(buffer);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("发送数据失败！原因：" + ex.Message, "提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }                
        //窗体加载事件
        private void SocketConfig_Load(object sender, EventArgs e)
        {
            //未连接成功状态
            BtnStopConnect();
        }
        //窗体关闭后事件
        private void SocketConfig_FormClosed(object sender, FormClosedEventArgs e)
        {
            //停止接收数据线程
            /*if (th != null && th.ThreadState == ThreadState.Running)  //逻辑表达式符号： 并且 &&  或者||   非!
            {
                try
                {
                    th.Abort();
                }
                catch (Exception)
                {
                }
            }*/
        }       
    }
}
