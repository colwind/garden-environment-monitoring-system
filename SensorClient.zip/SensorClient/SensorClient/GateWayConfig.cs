﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;

namespace SensorClient
{
    public partial class GateWayConfig : Form
    {
        /*
         * 网关参数配置类
         */
        public GateWayConfig()
        {
            InitializeComponent();
        }
        //保存网关相关参数
        private void btnsave_Click(object sender, EventArgs e)
        {
            //网关的IP
            #region MyRegion
            if (txtGateWayIP.Text.Trim() == string.Empty)
            {
                MessageBox.Show("请输入网关的IP地址？", "提示", MessageBoxButtons.OK, MessageBoxIcon.Question);
                return;
            }
            else
            {
                //点分四段的整数
                char[] sp = new char[] { '.' };
                string[] gateWayIP = txtGateWayIP.Text.Split(sp);
                if (gateWayIP.Length != 4)
                {
                    MessageBox.Show("网关的IP地址错误！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    int ip = 0;
                    bool flag = false;
                    //检查ip合法性
                    for (int i = 0; i < gateWayIP.Length; i++)
                    {
                        if (!int.TryParse(gateWayIP[i], out ip ))
                        {
                            flag = true;
                            break;
                        }
                    }
                    if (flag)
                    {
                        MessageBox.Show("网关的IP地址错误！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        //保存IP
                        MySocket.gateWayIP = txtGateWayIP.Text.Trim();
                        
                    }
                }
            } 
            #endregion
            //网关端口
            #region MyRegion
            if (txtGateWayPort.Text == string.Empty)
            {
                MessageBox.Show("请输入网关端口？", "提示", MessageBoxButtons.OK, MessageBoxIcon.Question);
                return;
            }
            else
            {
                int port = 0;
                if (!int.TryParse(txtGateWayPort.Text, out port))
                {
                    MessageBox.Show("网关端口错误！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    MySocket.gateWayPort = port;
                }
            } 
            #endregion
            //网关序列号
            #region MyRegion
            if (txtGateWaySeriaNumber.Text == string.Empty)
            {
                MessageBox.Show("请输入网关序列号？", "提示", MessageBoxButtons.OK, MessageBoxIcon.Question);
                return;
            }
            else
            {
                //点分三段的整数
                char[] sp = new char[] { '.' };
                string[] gateWaySN = txtGateWaySeriaNumber.Text.Split(sp);
                //判断是否三位
                if (gateWaySN.Length != 3)
                {
                    MessageBox.Show("网关序列号错误！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    //判断每一位
                    int gateWaySN1 = 0;
                    int gateWaySN2 = 0;
                    int gateWaySN3 = 0;

                    if (!int.TryParse(gateWaySN[0], out gateWaySN1))
                    {
                        MessageBox.Show("网关序列号错误！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else if (!int.TryParse(gateWaySN[1], out gateWaySN2))
                    {
                        MessageBox.Show("网关序列号错误！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else if (!int.TryParse(gateWaySN[2], out gateWaySN3))
                    {
                        MessageBox.Show("网关序列号错误！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        MySocket.gateWaySerialNumber = txtGateWaySeriaNumber.Text;
                    }
                }
            }
            #endregion
            //上报数据方式
            MySocket.gateWayUploadDataType = this.cbxUploadType.Text;//从下拉菜单中选中项的值
            //打出提示
            MessageBox.Show("保存网关参数成功！","提示",MessageBoxButtons.OK,MessageBoxIcon.Information);
            //关闭
            this.Close();
        }
        //清空网关相关参数
        private void btnclear_Click(object sender, EventArgs e)
        {
            this.txtGateWayIP.Text = string.Empty;
            this.txtGateWayPort.Text = string.Empty;
            this.txtGateWaySeriaNumber.Text = string.Empty;
            this.cbxUploadType.SelectedIndex = 0;

        }
        //窗体加载事件
        private void GateWayConfig_Load(object sender, EventArgs e)
        {
            //下拉菜单默认第一项
            this.cbxUploadType.SelectedIndex = 0;
        }
        //窗体关闭后事件
        private void GateWayConfig_FormClosed(object sender, FormClosedEventArgs e)
        {

        }
    }
}
